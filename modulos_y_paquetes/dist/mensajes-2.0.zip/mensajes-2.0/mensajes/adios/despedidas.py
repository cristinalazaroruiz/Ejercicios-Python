def despedir(variable):
    print(variable)

def estar_hasta_los_huevos():
    print("no puedo mas con la puta terminal")

class Despedida():
    despedida_guay = "Hata luego chavales"
    def __init__(self):
        print ("Adios, me despido desde Despedida.__init__()")
    def despedida_chula(self, i):
        print(i)
    