from mensajes.hola.saludos import * 
from mensajes.adios.despedidas import * 

saludar()
despedir("Hasta luego lucas")
Despedida().despedida_chula("Holiwis")

persona = Despedida()
print(persona.despedida_guay)