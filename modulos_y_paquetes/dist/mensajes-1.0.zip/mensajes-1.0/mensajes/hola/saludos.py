def saludar():
    print("Hola, te saludo desde saludos.saludar()")



if __name__ == '__main__':
    saludar() 